#ifndef __COMPAT_H
#define __COMPAT_H

#ifdef SOLARIS
typedef	unsigned char	u_int8_t;
typedef	unsigned short	u_int16_t;
typedef	unsigned int	u_int32_t;
#endif

#endif
